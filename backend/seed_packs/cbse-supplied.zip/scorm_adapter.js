/* ============================================================
   SCORM 1.2 adapter for the CBSE Virtual Labs library.
   Gracefully does nothing outside an LMS; inside one it marks
   the library as completed so progress tracking works.
   ============================================================ */
(function () {
  'use strict';

  function findAPI(win) {
    var tries = 0;
    while (win && tries++ < 12) {
      if (win.API && win.API.LMSInitialize) return win.API;
      if (win.parent === win) return null;
      win = win.parent;
    }
    return null;
  }

  var api = null;
  try { api = findAPI(window); } catch (e) { api = null; }

  if (!api) {
    // Not inside an LMS (file://, static hosting, plain iframe) — run standalone.
    return;
  }

  try {
    api.LMSInitialize('');
    api.LMSSetValue('cmi.core.lesson_status', 'completed');
    api.LMSSetValue('cmi.core.score.raw', '100');
    api.LMSCommit('');
    window.addEventListener('unload', function () {
      try { api.LMSFinish(''); } catch (e) { /* LMS already closed */ }
    });
  } catch (e) { /* never block the labs on SCORM quirks */ }
})();
