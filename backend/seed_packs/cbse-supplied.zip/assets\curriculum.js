/* Generated from CBSE_PCMB_Curriculum_Map_Class6-12.xlsx (new NCERT 2024-25 for classes 6-9). c: 1=Foundation 2=Core 3=Advanced. t = topics covered, k = key concepts (from the sheet). */
var CURRICULUM = [
 {
  "cls": 6,
  "theme": "Curiosity & foundations - noticing how the world works",
  "subjects": [
   {
    "name": "Mathematics",
    "chapters": [
     {
      "n": "1. Patterns in Mathematics",
      "t": "Number sequences; visual/shape patterns; relating number patterns to pictures; patterns in triangular, square and cube numbers",
      "k": "Pattern recognition as the core of mathematics; generalising a rule from examples; linking arithmetic patterns to geometric arrangements",
      "c": 1
     },
     {
      "n": "2. Lines and Angles",
      "t": "Point, line, line segment, ray; angles and their measure; degree measure; types of angles; using a protractor",
      "k": "Angle as a measure of turning/rotation; acute, right, obtuse, straight, reflex; constructing and comparing angles",
      "c": 1
     },
     {
      "n": "3. Number Play",
      "t": "Number puzzles; supercells; digit patterns; Collatz-type sequences; estimation; playing with digits",
      "k": "Place value reasoning; systematic trial; estimation and mental arithmetic; number sense before algorithms",
      "c": 1
     , "lab": "labs/math/number-lab.html"},
     {
      "n": "4. Data Handling and Presentation",
      "t": "Collecting and organising data; tally marks; pictographs; bar graphs; scale on a graph; drawing inferences",
      "k": "Data as evidence; representation choice affects readability; reading and interpreting charts",
      "c": 1,
      "lab": "labs/math/statistics-lab.html"
     },
     {
      "n": "5. Prime Time",
      "t": "Factors and multiples; prime and composite numbers; prime factorisation; co-primes; divisibility tests; HCF and LCM ideas",
      "k": "Fundamental theorem of arithmetic (intuitive); Sieve of Eratosthenes; divisibility rules for 2,3,4,5,6,9,10",
      "c": 1
     , "lab": "labs/math/number-lab.html"},
     {
      "n": "6. Perimeter and Area",
      "t": "Perimeter of rectangle, square, triangle; area by counting squares; area of rectangle and square; irregular figures",
      "k": "Perimeter as boundary length vs area as surface covered; conservation of area; unit squares",
      "c": 1,
      "lab": "labs/math/solids-3d.html",
      "x": "3D"
     },
     {
      "n": "7. Fractions",
      "t": "Fraction as part of a whole; on the number line; equivalent fractions; comparing; addition and subtraction of fractions; mixed numbers",
      "k": "Fraction as a number, not just a shaded picture; equivalence via multiplication/division; common denominators",
      "c": 1,
      "lab": "labs/math/fractions-explorer.html"
     },
     {
      "n": "8. Playing with Constructions",
      "t": "Constructions with ruler and compass; circles; perpendiculars; squares and rectangles; angle copying",
      "k": "Geometric construction as reasoning; compass preserves length; constructing before measuring",
      "c": 1
     },
     {
      "n": "9. Symmetry",
      "t": "Line (reflection) symmetry; rotational symmetry; order of rotation; symmetry in figures and designs",
      "k": "Symmetry as invariance under a transformation; axis of symmetry; centre and order of rotation",
      "c": 1,
      "lab": "labs/math/symmetry-3d.html",
      "x": "3D·XR"
     },
     {
      "n": "10. The Other Side of Zero",
      "t": "Negative numbers; integers on the number line; addition and subtraction of integers; contexts (temperature, debt, altitude)",
      "k": "Extension of number system below zero; additive inverse; ordering of integers; zero as reference point",
      "c": 1
     }
    ]
   },
   {
    "name": "Science (Integrated)",
    "chapters": [
     {
      "n": "1. The Wonderful World of Science",
      "t": "What science is; branches of science; scientific method; observation, hypothesis, experiment; role of curiosity",
      "k": "Scientific temper; inquiry cycle; evidence-based reasoning",
      "c": 1
     },
     {
      "n": "2. Diversity in the Living World",
      "t": "Variety in plants and animals; habitats; grouping living things; herbs, shrubs, trees; classification basics",
      "k": "Biodiversity; classification by observable characteristics; adaptation to habitat",
      "c": 1
     },
     {
      "n": "3. Mindful Eating: A Path to a Healthy Body",
      "t": "Components of food; carbohydrates, proteins, fats, vitamins, minerals, roughage, water; balanced diet; deficiency diseases; food tests",
      "k": "Nutrients and their functions; balanced diet; deficiency diseases (scurvy, rickets, anaemia); iodine/Benedict's tests",
      "c": 1
     },
     {
      "n": "4. Exploring Magnets",
      "t": "Magnetic and non-magnetic materials; poles of a magnet; attraction and repulsion; magnetic compass; making a magnet",
      "k": "Magnetism as a property of certain materials; like poles repel, unlike attract; Earth as a magnet; directional property",
      "c": 1,
      "lab": "labs/science/magnet-lab.html"
     },
     {
      "n": "5. Measurement of Length and Motion",
      "t": "Need for standard units; SI units; measuring length correctly; types of motion — rectilinear, circular, periodic",
      "k": "Standardisation of measurement; least count and parallax error; motion as change of position with time",
      "c": 1,
      "lab": "labs/science/motion-graphs.html"
     },
     {
      "n": "6. Materials Around Us",
      "t": "Objects and materials; properties — appearance, hardness, solubility, density, transparency; grouping materials",
      "k": "Property-based classification; floats/sinks; soluble vs insoluble; transparent, translucent, opaque",
      "c": 1
     },
     {
      "n": "7. Temperature and its Measurement",
      "t": "Hot and cold; thermometers (clinical and laboratory); Celsius scale; measuring body and water temperature",
      "k": "Temperature as degree of hotness (distinct from heat); calibration; safe measurement practice",
      "c": 1,
      "lab": "labs/science/heat-transfer-lab.html"
     },
     {
      "n": "8. A Journey through States of Water",
      "t": "Solid, liquid, gas; melting, boiling, evaporation, condensation, freezing; water cycle; humidity",
      "k": "Change of state as a physical change; latent heat (intuitive); the water cycle as a closed system",
      "c": 1,
      "lab": "labs/science/water-states-3d.html",
      "x": "3D·XR"
     },
     {
      "n": "9. Methods of Separation in Everyday Life",
      "t": "Handpicking, threshing, winnowing, sieving, sedimentation, decantation, filtration, evaporation, condensation",
      "k": "Separation based on difference in physical properties; pure vs impure; saturated solutions",
      "c": 1
     , "lab": "labs/science/separation-lab.html"},
     {
      "n": "10. Living Creatures: Exploring their Characteristics",
      "t": "Characteristics of living things — growth, respiration, response, reproduction, excretion, movement, nutrition; living vs non-living",
      "k": "Life processes as defining criteria; stimulus and response; life cycle",
      "c": 1
     },
     {
      "n": "11. Nature's Treasures",
      "t": "Natural resources — air, water, soil, minerals, forests; renewable and non-renewable; conservation; distribution of resources",
      "k": "Resource classification; sustainable use; interdependence of humans and nature",
      "c": 1
     },
     {
      "n": "12. Beyond Earth",
      "t": "Stars, constellations, planets, Moon; phases of the Moon; solar system; artificial satellites; space missions",
      "k": "Celestial bodies and their motions; Moon phases from relative positions; scale of the solar system",
      "c": 1,
      "lab": "labs/science/solar-system-3d.html",
      "x": "3D"
     }
    ]
   }
  ]
 },
 {
  "cls": 7,
  "theme": "Patterns & processes - connecting everyday phenomena",
  "subjects": [
   {
    "name": "Mathematics",
    "chapters": [
     {
      "n": "1. Large Numbers Around Us",
      "t": "Reading/writing large numbers; Indian vs International system; place value; comparing; rounding and estimation",
      "k": "Place value structure; approximation and estimation as valid mathematics; orders of magnitude",
      "c": 1
     },
     {
      "n": "2. Arithmetic Expressions",
      "t": "Writing and reading expressions; brackets; order of operations; equality of expressions; word problems to expressions",
      "k": "Structure of an expression; BODMAS/order of operations; expression vs equation",
      "c": 1
     },
     {
      "n": "3. A Peek Beyond the Point",
      "t": "Decimals — tenths, hundredths, thousandths; place value with decimals; comparing and ordering; number line; addition and subtraction; units of measure",
      "k": "Decimal as an extension of place value; equivalence of decimals and fractions; measurement precision",
      "c": 1
     },
     {
      "n": "4. Expressions using Letter-Numbers",
      "t": "Using letters for numbers; forming algebraic expressions; simplification; patterns and generalisation; formulas",
      "k": "Variable as a generalised number; algebraic generalisation of arithmetic patterns; terms and coefficients",
      "c": 1
     },
     {
      "n": "5. Parallel and Intersecting Lines",
      "t": "Intersecting and parallel lines; transversal; corresponding, alternate and co-interior angles; constructing parallel lines",
      "k": "Angle relationships formed by a transversal; parallelism criteria; deductive angle reasoning",
      "c": 1
     },
     {
      "n": "6. Number Play",
      "t": "Digit puzzles; number patterns; divisibility explorations; magic squares; interesting number properties",
      "k": "Reasoning with number structure; proof by exhaustive checking; conjecture and verification",
      "c": 1
     },
     {
      "n": "7. A Tale of Three Intersecting Lines",
      "t": "Triangles; angle sum property; exterior angle property; triangle inequality; types of triangles; construction",
      "k": "Angle sum = 180 degrees; exterior angle theorem; triangle inequality as a constructibility condition",
      "c": 1
     , "lab": "labs/math/triangles-lab.html"},
     {
      "n": "8. Working with Fractions",
      "t": "Multiplication and division of fractions; fraction of a fraction; reciprocals; word problems; fractions in measurement",
      "k": "Multiplication as scaling; division by a fraction as multiplying by the reciprocal; area model of fraction multiplication",
      "c": 1,
      "lab": "labs/math/fractions-explorer.html"
     },
     {
      "n": "9. Geometric Twins",
      "t": "Congruence of figures; criteria for congruent triangles (SSS, SAS, ASA, RHS); symmetry and congruence",
      "k": "Congruence as exact superposition; minimum conditions for congruence; correspondence of vertices",
      "c": 1
     , "lab": "labs/math/triangles-lab.html"},
     {
      "n": "10. Operations with Integers",
      "t": "Addition, subtraction, multiplication and division of integers; properties; number line models; real-life contexts",
      "k": "Sign rules derived from patterns, not memorised; closure and commutativity; additive inverse",
      "c": 1
     },
     {
      "n": "11. Finding Common Ground",
      "t": "Factors and multiples; HCF and LCM; prime factorisation methods; applications to word problems",
      "k": "HCF/LCM as structural tools; relation HCF x LCM = product of two numbers; problem modelling",
      "c": 1
     , "lab": "labs/math/number-lab.html"},
     {
      "n": "12. Another Peek Beyond the Point",
      "t": "Multiplication and division of decimals; decimals and fractions interconversion; terminating and recurring decimals",
      "k": "Decimal operations via place value; conversion between representations; precision and rounding",
      "c": 1
     },
     {
      "n": "13. Connecting the Dots",
      "t": "Data collection and organisation; bar graphs, double bar graphs, pie-chart intuition; mean, median, mode; chance",
      "k": "Measures of central tendency; representation choice; introduction to likelihood",
      "c": 1
     },
     {
      "n": "14. Constructions and Tilings",
      "t": "Constructions with compass and straight-edge; tilings and tessellations; regular polygons; symmetry in patterns",
      "k": "Which shapes tile the plane and why; angle around a point = 360 degrees; construction as proof",
      "c": 1
     },
     {
      "n": "15. Finding the Unknown",
      "t": "Simple linear equations; forming equations from word problems; solving by balancing and transposition; verification",
      "k": "Equation as a balance; inverse operations; solution and verification",
      "c": 1,
      "lab": "labs/math/line-explorer.html"
     }
    ]
   },
   {
    "name": "Science (Integrated)",
    "chapters": [
     {
      "n": "1. The Ever-Evolving World of Science",
      "t": "How scientific knowledge changes; famous discoveries; scientific method revisited; role of evidence",
      "k": "Science as self-correcting; hypothesis testing; models change with new evidence",
      "c": 1
     },
     {
      "n": "2. Exploring Substances: Acidic, Basic and Neutral",
      "t": "Acids and bases; natural indicators (litmus, turmeric, china rose); neutralisation; acids and bases in daily life",
      "k": "Acid-base character; indicators as detection tools; neutralisation reaction and its applications",
      "c": 1,
      "lab": "labs/science/acids-bases-ph.html"
     },
     {
      "n": "3. Electricity: Circuits and their Components",
      "t": "Electric cell, bulb, switch, wires; circuit diagrams and symbols; open and closed circuits; conductors and insulators; heating and magnetic effect",
      "k": "Closed circuit is necessary for current; circuit symbols as a standard language; effects of electric current",
      "c": 1,
      "lab": "labs/science/electric-circuits.html"
     },
     {
      "n": "4. The World of Metals and Non-metals",
      "t": "Physical properties — lustre, malleability, ductility, conductivity, sonority; chemical properties; reaction with air, water, acids; uses",
      "k": "Property-based classification of elements; reactivity differences; corrosion and rusting",
      "c": 1,
      "lab": "labs/science/reactivity-series.html"
     },
     {
      "n": "5. Changes Around Us: Physical and Chemical",
      "t": "Physical vs chemical changes; reversible and irreversible; rusting; crystallisation; evidence of chemical change",
      "k": "Criteria distinguishing physical and chemical change; conservation of matter; new substance formation",
      "c": 1,
      "lab": "labs/science/balance-equations.html"
     },
     {
      "n": "6. Adolescence: A Stage of Growth and Change",
      "t": "Puberty and its changes; endocrine glands and hormones; reproductive health; nutrition and hygiene in adolescence",
      "k": "Hormonal control of growth; secondary sexual characters; healthy habits and personal hygiene",
      "c": 1
     },
     {
      "n": "7. Heat Transfer in Nature",
      "t": "Conduction, convection, radiation; conductors and insulators of heat; land and sea breeze; applications",
      "k": "Three modes of heat transfer; heat flows from hot to cold; thermal insulation",
      "c": 1,
      "lab": "labs/science/heat-transfer-lab.html"
     },
     {
      "n": "8. Measurement of Time and Motion",
      "t": "Measuring time; simple pendulum; speed; distance-time graphs; uniform and non-uniform motion; units of speed",
      "k": "Speed = distance/time; periodic motion as a clock; graphical representation of motion",
      "c": 1,
      "lab": "labs/science/motion-graphs.html"
     },
     {
      "n": "9. Life Processes in Animals",
      "t": "Nutrition in animals; digestion in humans and ruminants; respiration; circulation and transport; excretion",
      "k": "Organ systems and their coordination; digestion as breakdown for absorption; gas exchange",
      "c": 1,
      "lab": "labs/biology/photosynthesis-lab.html"
     },
     {
      "n": "10. Life Processes in Plants",
      "t": "Photosynthesis; modes of nutrition; transport of water and food; transpiration; respiration in plants",
      "k": "Autotrophic nutrition; xylem and phloem transport; stomata and transpiration pull",
      "c": 1,
      "lab": "labs/biology/photosynthesis-lab.html"
     },
     {
      "n": "11. Light: Shadows and Reflections",
      "t": "Rectilinear propagation; shadows; pinhole camera; reflection; plane mirror images; lateral inversion; spherical mirrors intro",
      "k": "Light travels in straight lines; laws of reflection; image characteristics in a plane mirror",
      "c": 1,
      "lab": "labs/science/light-optics.html"
     },
     {
      "n": "12. Earth, Moon, and the Sun",
      "t": "Rotation and revolution; day and night; seasons; phases of the Moon; eclipses; the celestial sphere",
      "k": "Axial tilt causes seasons; relative motion explains phases and eclipses; frames of reference",
      "c": 1,
      "lab": "labs/science/earth-moon-sun-3d.html",
      "x": "3D·XR"
     }
    ]
   }
  ]
 },
 {
  "cls": 8,
  "theme": "Systems & models - matter, force, sky and Earth",
  "subjects": [
   {
    "name": "Mathematics",
    "chapters": [
     {
      "n": "1. A Square and A Cube",
      "t": "Square numbers and their patterns; square roots; cube numbers; cube roots; estimation of roots",
      "k": "Perfect squares and cubes; inverse operations; patterns in square/cube number sequences",
      "c": 1
     },
     {
      "n": "2. Power Play",
      "t": "Exponents and powers; laws of exponents; negative exponents; standard (scientific) form; very large and small numbers",
      "k": "Exponent as repeated multiplication; laws of indices; scientific notation for magnitude",
      "c": 1
     },
     {
      "n": "3. A Story of Numbers",
      "t": "Development of number systems; rational numbers; properties and operations; representation on the number line",
      "k": "Historical growth of number concepts; closure properties; density of rationals",
      "c": 1
     },
     {
      "n": "4. Quadrilaterals",
      "t": "Types of quadrilaterals; angle sum property; properties of parallelogram, rhombus, rectangle, square, trapezium; diagonals",
      "k": "Hierarchy of quadrilaterals; angle sum = 360 degrees; property-based classification and proof",
      "c": 1
     },
     {
      "n": "5. Number Play",
      "t": "Divisibility explorations; digit patterns; number puzzles and games; reasoning about number properties",
      "k": "Conjecture, test, generalise; divisibility reasoning; proof by algebraic representation of digits",
      "c": 1
     },
     {
      "n": "6. We Distribute, Yet Things Multiply",
      "t": "Distributive property; algebraic expressions; multiplication of expressions; area models; expansion",
      "k": "Distributivity as the bridge from arithmetic to algebra; area model of products; like and unlike terms",
      "c": 1
     },
     {
      "n": "7. Proportional Reasoning-1",
      "t": "Ratio and proportion; unitary method; direct variation; inverse variation; scale and maps",
      "k": "Proportional relationship as constant ratio; direct vs inverse variation; scaling",
      "c": 1
     },
     {
      "n": "8. Fractions in Disguise",
      "t": "Equivalent fractions; rational numbers in different forms; decimal and percentage forms; comparison",
      "k": "Multiple representations of the same number; equivalence classes; conversion fluency",
      "c": 1,
      "lab": "labs/math/fractions-explorer.html"
     },
     {
      "n": "9. The Baudhayana-Pythagoras Theorem",
      "t": "Right triangles; statement and proof of the theorem; Pythagorean triples; applications; Indian mathematical history (Sulbasutras)",
      "k": "Relation among sides of a right triangle; geometric proof by area; converse of the theorem",
      "c": 1,
      "lab": "labs/math/pythagoras-explorer.html"
     },
     {
      "n": "10. Proportional Reasoning-2",
      "t": "Percentage; profit and loss; discount; simple interest; compound interest; taxes",
      "k": "Percentage as a proportion out of hundred; multiplicative change; growth over periods",
      "c": 1
     },
     {
      "n": "11. Exploring Some Geometric Themes",
      "t": "Geometric constructions; symmetry; geometric patterns; polygons; angle properties",
      "k": "Construction as reasoning; symmetry groups intuitively; interior/exterior angles of polygons",
      "c": 1
     },
     {
      "n": "12. Tales by Dots and Lines",
      "t": "Coordinate plane; plotting points; reading and drawing graphs; linear graphs; data representation",
      "k": "Coordinates as an address system; graph as a picture of a relationship; interpreting slope informally",
      "c": 1
     },
     {
      "n": "13. Algebra Play",
      "t": "Algebraic expressions and identities; standard identities; factorisation; solving linear equations",
      "k": "Identity vs equation; factorisation as reverse of expansion; algebraic manipulation",
      "c": 1,
      "lab": "labs/math/line-explorer.html"
     },
     {
      "n": "14. Area",
      "t": "Area and perimeter of plane figures; trapezium, parallelogram, rhombus, polygons; area of circle; surface area intro",
      "k": "Decomposition into known shapes; derivation of area formulas; units and dimensional consistency",
      "c": 1,
      "lab": "labs/math/solids-3d.html",
      "x": "3D"
     }
    ]
   },
   {
    "name": "Science (Integrated)",
    "chapters": [
     {
      "n": "1. Exploring the Investigative World of Science",
      "t": "Nature of scientific inquiry; designing investigations; variables; recording and interpreting observations",
      "k": "Controlled experiment; dependent/independent variables; reproducibility",
      "c": 1
     },
     {
      "n": "2. The Invisible Living World: Beyond Our Naked Eye",
      "t": "Microorganisms — bacteria, fungi, protozoa, algae, viruses; useful and harmful microbes; fermentation; food preservation; nitrogen cycle",
      "k": "Microbes as a distinct living world; pathogens and disease transmission; beneficial microbial processes",
      "c": 1
     },
     {
      "n": "3. Health: The Ultimate Treasure",
      "t": "Communicable and non-communicable disease; immunity; vaccination; nutrition; hygiene; lifestyle diseases",
      "k": "Disease causation; immune response; prevention over cure; public health",
      "c": 1
     },
     {
      "n": "4. Electricity: Magnetic and Heating Effects",
      "t": "Heating effect of current; electric fuse; magnetic effect; electromagnet; electric bell; electroplating basics",
      "k": "Current produces heat and magnetic field; electromagnet strength factors; safety devices",
      "c": 1,
      "lab": "labs/science/magnetism-current.html"
     },
     {
      "n": "5. Exploring Forces",
      "t": "Contact and non-contact forces; friction; pressure; effects of force; force as push or pull; balanced/unbalanced",
      "k": "Force changes state of motion or shape; friction as opposing motion; pressure = force/area",
      "c": 1,
      "lab": "labs/science/force-pressure-friction.html"
     },
     {
      "n": "6. Pressure, Winds, Storms, and Cyclones",
      "t": "Atmospheric pressure; air pressure and wind; thunderstorms; cyclones; safety measures",
      "k": "Pressure differences drive winds; low pressure systems; disaster preparedness",
      "c": 1,
      "lab": "labs/science/wind-pressure-lab.html"
     },
     {
      "n": "7. Particulate Nature of Matter",
      "t": "Particle model of matter; states of matter; diffusion; effect of temperature and pressure; interparticle forces",
      "k": "Matter is made of particles in motion; state depends on particle arrangement and energy",
      "c": 1,
      "lab": "labs/chemistry/ideal-gas-lab.html"
     },
     {
      "n": "8. Nature of Matter: Elements, Compounds, and Mixtures",
      "t": "Pure substances; elements and symbols; compounds; homogeneous and heterogeneous mixtures; properties",
      "k": "Classification of matter; compound vs mixture (fixed ratio, new properties); chemical symbols",
      "c": 1
     , "lab": "labs/chemistry/periodic-table-lab.html"},
     {
      "n": "9. The Amazing World of Solutes, Solvents, and Solutions",
      "t": "Solute, solvent, solution; solubility; saturated and unsaturated solutions; concentration; separation techniques",
      "k": "Solubility depends on temperature and nature of substances; concentration expressions; crystallisation",
      "c": 1,
      "lab": "labs/chemistry/titration-lab.html"
     },
     {
      "n": "10. Light: Mirrors and Lenses",
      "t": "Reflection and refraction; spherical mirrors; convex and concave lenses; image formation; ray diagrams; human eye",
      "k": "Ray model of light; image characteristics (real/virtual, erect/inverted, magnified); focal length",
      "c": 1,
      "lab": "labs/science/light-optics.html"
     },
     {
      "n": "11. Keeping Time with the Skies",
      "t": "Celestial motion; solar and lunar calendars; sundials; timekeeping through astronomy; Indian calendars",
      "k": "Astronomical periodicity as the basis of time units; apparent motion of celestial bodies",
      "c": 1,
      "lab": "labs/science/sundial-3d.html",
      "x": "3D·XR"
     },
     {
      "n": "12. How Nature Works in Harmony",
      "t": "Ecosystems; food chains and webs; energy flow; interdependence; biogeochemical cycles; balance in nature",
      "k": "Trophic levels; producer-consumer-decomposer; ecological balance and disturbance",
      "c": 1
     },
     {
      "n": "13. Our Home: Earth, a Unique Life Sustaining Planet",
      "t": "Earth's spheres — atmosphere, hydrosphere, lithosphere, biosphere; conditions for life; environmental protection",
      "k": "Earth systems interact; Goldilocks conditions for life; human impact and sustainability",
      "c": 1
     }
    ]
   }
  ]
 },
 {
  "cls": 9,
  "theme": "The bridge year - science turns quantitative",
  "subjects": [
   {
    "name": "Mathematics",
    "chapters": [
     {
      "n": "1. Orienting Yourself: The Use of Coordinates",
      "t": "Cartesian coordinate system; axes and quadrants; plotting points; distance formula; midpoint formula",
      "k": "Coordinates link algebra and geometry; sign conventions by quadrant; distance derived from Pythagoras",
      "c": 2
     },
     {
      "n": "2. Introduction to Linear Polynomials",
      "t": "Algebraic expressions; polynomials and degree; linear polynomials; zeroes; slope and y-intercept; linear growth and decay",
      "k": "Polynomial as a formal object; zero of a polynomial; linear relationship as constant rate of change",
      "c": 2
     },
     {
      "n": "3. The World of Numbers",
      "t": "Rational and irrational numbers; real number line; density of rationals; proofs of irrationality of root 2 and root 3; decimal expansions; laws of exponents for real numb",
      "k": "Real number system completeness; proof by contradiction; terminating vs non-terminating recurring decimals",
      "c": 2
     },
     {
      "n": "4. Exploring Algebraic Identities",
      "t": "Standard algebraic identities; geometric models of identities; factorisation; simplifying rational expressions",
      "k": "Identity holds for all values; area/volume models as visual proof; factorisation techniques",
      "c": 2
     },
     {
      "n": "5. I'm Up and Down, and Round and Round",
      "t": "Periodic and oscillatory phenomena; graphs of repeating behaviour; circular motion; introduction to periodicity",
      "k": "Periodicity as a mathematical pattern; amplitude and period informally; modelling cyclic phenomena",
      "c": 2
     },
     {
      "n": "6. Measuring Space: Perimeter and Area",
      "t": "Perimeter and area of plane figures; Heron's formula; area of triangles and quadrilaterals; applications",
      "k": "Heron's formula for any triangle from sides; decomposition strategy; measurement in context",
      "c": 2,
      "lab": "labs/math/solids-3d.html",
      "x": "3D"
     },
     {
      "n": "7. The Mathematics of Maybe: Introduction to Probability",
      "t": "Random experiments; outcomes and events; empirical probability; relative frequency; simple problems",
      "k": "Probability as long-run relative frequency; sample space; certainty, impossibility and the 0-1 scale",
      "c": 2,
      "lab": "labs/math/probability-lab.html"
     },
     {
      "n": "8. Predicting What Comes Next?: Exploring Sequences and Progressions",
      "t": "Sequences; arithmetic progressions; geometric progressions; nth term; sums; real-life contexts (EMI, population growth, Tower of Hanoi, fractals)",
      "k": "AP as constant difference and GP as constant ratio; generalising the nth term; modelling growth",
      "c": 2
     , "lab": "labs/math/progressions-lab.html"}
    ]
   },
   {
    "name": "Science (Integrated)",
    "chapters": [
     {
      "n": "1. Exploration: Entering the World of Secondary Science",
      "t": "Nature and branches of science; scientific investigation; models and evidence; measurement and units",
      "k": "Scientific method at secondary level; model building; from observation to explanation",
      "c": 2
     },
     {
      "n": "2. Cell: The Building Block of Life",
      "t": "Prokaryotic and eukaryotic cells; plant vs animal cells; nucleus, mitochondria, chloroplast, ER, Golgi, vacuoles, plasma membrane, cell wall; osmosis and diffusion; mitos",
      "k": "Cell theory; structure-function relationship of organelles; membrane permeability; cell division",
      "c": 2,
      "lab": "labs/science/plant-animal-cell.html"
     },
     {
      "n": "3. Tissues in Action",
      "t": "Plant tissues — meristematic and permanent; animal tissues — epithelial, connective, muscular, nervous; structure and function",
      "k": "Division of labour among tissues; tissue as a group of similar cells with a common function",
      "c": 2
     },
     {
      "n": "4. Describing Motion Around Us",
      "t": "Distance and displacement; speed and velocity; acceleration; equations of motion; distance-time and velocity-time graphs; uniform circular motion",
      "k": "Scalars vs vectors; graphical analysis of motion; derivation of kinematic equations",
      "c": 2,
      "lab": "labs/science/motion-graphs.html"
     },
     {
      "n": "5. Exploring Mixtures and their Separation",
      "t": "Pure substances and mixtures; solutions, colloids, suspensions; concentration; Tyndall effect; separation techniques — chromatography, distillation, centrifugation, subli",
      "k": "Classification by particle size and homogeneity; physical vs chemical separation; solubility",
      "c": 2
     , "lab": "labs/science/separation-lab.html"},
     {
      "n": "6. How Forces Affect Motion",
      "t": "Balanced and unbalanced forces; Newton's three laws of motion; inertia and mass; momentum; conservation of momentum; friction",
      "k": "Force as cause of change in momentum; inertia; action-reaction pairs; conservation principle",
      "c": 2,
      "lab": "labs/science/force-pressure-friction.html"
     },
     {
      "n": "7. Work, Energy and Simple Machines",
      "t": "Work done by a force; kinetic and potential energy; law of conservation of energy; power; simple machines and mechanical advantage",
      "k": "Work-energy theorem; energy transformation; machines trade force for distance",
      "c": 2,
      "lab": "labs/physics/simple-pendulum.html"
     },
     {
      "n": "8. Journey Inside the Atom",
      "t": "Discovery of electron, proton, neutron; Thomson, Rutherford and Bohr models; atomic number and mass number; isotopes and isobars; electronic configuration; valency",
      "k": "Evolution of atomic models from evidence; shell structure; valency from outermost electrons",
      "c": 2,
      "lab": "labs/science/atom-builder-3d.html",
      "x": "3D"
     },
     {
      "n": "9. Atomic Foundations of Matter",
      "t": "Law of conservation of mass; law of constant proportions; Dalton's atomic theory; atoms and molecules; chemical formulae; ionic and covalent bonding; molecular and formul",
      "k": "Quantitative laws underpin atomic theory; bonding from electron transfer/sharing; the mole as a counting unit",
      "c": 2,
      "lab": "labs/science/atom-builder-3d.html",
      "x": "3D"
     },
     {
      "n": "10. Sound Waves: Characteristics and Applications",
      "t": "Production and propagation of sound; longitudinal waves; frequency, amplitude, wavelength, pitch, loudness; speed of sound; reflection and echo; SONAR; human ear",
      "k": "Sound as a mechanical wave needing a medium; wave characteristics and perception; echo and reverberation",
      "c": 2,
      "lab": "labs/physics/wave-motion.html"
     },
     {
      "n": "11. Reproduction: How Life Continues",
      "t": "Asexual and sexual reproduction; reproduction in plants and animals; human reproductive system; fertilisation; reproductive health",
      "k": "Continuity of life; variation through sexual reproduction; gamete formation",
      "c": 2
     , "lab": "labs/science/reproduction-lab.html"},
     {
      "n": "12. Patterns in Life - Diversity and Classification",
      "t": "Need for classification; hierarchy of classification; five kingdoms; plant and animal kingdom groups; evolutionary relationships",
      "k": "Hierarchical classification reflects evolutionary relatedness; binomial nomenclature; characters used for grouping",
      "c": 2
     },
     {
      "n": "13. Earth as a System: Energy, Matter and Life",
      "t": "Earth's spheres and their interactions; solar energy input; biogeochemical cycles (carbon, nitrogen, water); climate; human impact",
      "k": "Earth as an interconnected system; matter cycles while energy flows; anthropogenic change",
      "c": 2
     }
    ]
   }
  ]
 },
 {
  "cls": 10,
  "theme": "Board year - synthesize, apply, score",
  "subjects": [
   {
    "name": "Mathematics",
    "chapters": [
     {
      "n": "1. Real Numbers",
      "t": "Fundamental Theorem of Arithmetic; HCF and LCM by prime factorisation; irrationality proofs; revisiting rational numbers",
      "k": "Unique prime factorisation; proof by contradiction; HCF x LCM = product of two numbers",
      "c": 2
     , "lab": "labs/math/number-lab.html"},
     {
      "n": "2. Polynomials",
      "t": "Degree; zeroes of a polynomial; geometrical meaning of zeroes; relationship between zeroes and coefficients",
      "k": "Zero as x-intercept; sum and product of zeroes of a quadratic; polynomial as a function",
      "c": 2,
      "lab": "labs/math/quadratic-explorer.html"
     },
     {
      "n": "3. Pair of Linear Equations in Two Variables",
      "t": "Graphical method; substitution; elimination; consistency and inconsistency; equations reducible to linear form",
      "k": "Solution as intersection of lines; consistent/inconsistent/dependent systems; ratio test of coefficients",
      "c": 2,
      "lab": "labs/math/line-explorer.html"
     },
     {
      "n": "4. Quadratic Equations",
      "t": "Standard form; roots by factorisation; quadratic formula; discriminant and nature of roots; word problems",
      "k": "Discriminant determines root nature; completing the square; modelling with quadratics",
      "c": 2,
      "lab": "labs/math/quadratic-explorer.html"
     },
     {
      "n": "5. Arithmetic Progressions",
      "t": "nth term of an AP; sum of first n terms; applications and word problems",
      "k": "Constant common difference; general term formula; sum formulas and their derivation",
      "c": 2
     , "lab": "labs/math/progressions-lab.html"},
     {
      "n": "6. Triangles",
      "t": "Similarity of triangles; Basic Proportionality (Thales) Theorem; criteria for similarity (AAA, SSS, SAS); ratio of areas",
      "k": "Similarity vs congruence; proportionality of corresponding sides; geometric proof",
      "c": 2
     , "lab": "labs/math/triangles-lab.html"},
     {
      "n": "7. Coordinate Geometry",
      "t": "Distance formula; section formula; midpoint; applications",
      "k": "Algebraic treatment of geometry; internal division of a line segment",
      "c": 2
     },
     {
      "n": "8. Introduction to Trigonometry",
      "t": "Trigonometric ratios; ratios of specific angles (0,30,45,60,90); trigonometric identities",
      "k": "Ratios defined by right triangle sides; fundamental identity sin^2 + cos^2 = 1; complementary angles",
      "c": 3,
      "lab": "labs/math/trigonometry-explorer.html"
     },
     {
      "n": "9. Some Applications of Trigonometry",
      "t": "Heights and distances; angle of elevation and depression; real-life problems",
      "k": "Modelling physical situations with right triangles; line of sight",
      "c": 3
     },
     {
      "n": "10. Circles",
      "t": "Tangent to a circle; number of tangents from a point; tangent-radius perpendicularity; lengths of tangents",
      "k": "Tangent touches at exactly one point; tangent perpendicular to radius; equal tangents from an external point",
      "c": 2
     , "lab": "labs/math/circles-lab.html"},
     {
      "n": "11. Areas Related to Circles",
      "t": "Area and circumference; area of sector and segment; combinations of plane figures",
      "k": "Proportional reasoning with central angle; composite area by addition/subtraction",
      "c": 2
     , "lab": "labs/math/circles-lab.html"},
     {
      "n": "12. Surface Areas and Volumes",
      "t": "Surface area and volume of combinations of solids — cuboid, cone, cylinder, sphere, hemisphere; conversion of solids",
      "k": "Additivity of surface area vs volume; conservation of volume on recasting",
      "c": 2
     },
     {
      "n": "13. Statistics",
      "t": "Mean, median and mode of grouped data; cumulative frequency; ogive",
      "k": "Central tendency for grouped data; assumed mean and step-deviation methods",
      "c": 2,
      "lab": "labs/math/statistics-lab.html"
     },
     {
      "n": "14. Probability",
      "t": "Theoretical (classical) probability; simple problems on cards, dice, coins; complementary events",
      "k": "P(E) = favourable/total; sum of probabilities of an event and its complement = 1",
      "c": 2,
      "lab": "labs/math/probability-lab.html"
     }
    ]
   },
   {
    "name": "Science (Integrated)",
    "chapters": [
     {
      "n": "1. Chemical Reactions and Equations",
      "t": "Chemical equations and balancing; types of reactions — combination, decomposition, displacement, double displacement; oxidation and reduction; corrosion; rancidity",
      "k": "Conservation of mass in balancing; redox as electron/oxygen transfer; reaction classification",
      "c": 2,
      "lab": "labs/science/balance-equations.html"
     },
     {
      "n": "2. Acids, Bases and Salts",
      "t": "Properties of acids and bases; reaction with metals, carbonates, each other; pH scale; importance of pH; common salts and their preparation; water of crystallisation",
      "k": "Neutralisation; pH as a measure of H+ concentration; salt families and uses",
      "c": 2,
      "lab": "labs/science/acids-bases-ph.html"
     },
     {
      "n": "3. Metals and Non-metals",
      "t": "Physical and chemical properties; reactivity series; ionic compounds; extraction of metals; corrosion and prevention",
      "k": "Reactivity series predicts displacement; ionic bonding; metallurgy stages",
      "c": 2,
      "lab": "labs/science/reactivity-series.html"
     },
     {
      "n": "4. Carbon and its Compounds",
      "t": "Covalent bonding; allotropes; versatile nature of carbon; homologous series; nomenclature; combustion and oxidation; addition and substitution; ethanol and ethanoic acid;",
      "k": "Catenation and tetravalency; functional groups; homologous series regularity; micelle formation",
      "c": 2,
      "lab": "labs/chemistry/molecule-viewer-3d.html",
      "x": "3D"
     },
     {
      "n": "5. Life Processes",
      "t": "Nutrition — autotrophic and heterotrophic; human digestive system; respiration (aerobic/anaerobic); transport in humans and plants; excretion in humans and plants",
      "k": "Life processes maintain the living state; structure-function coupling; double circulation",
      "c": 2,
      "lab": "labs/biology/photosynthesis-lab.html"
     },
     {
      "n": "6. Control and Coordination",
      "t": "Nervous system; reflex action; human brain; coordination in plants (tropisms, plant hormones); endocrine system and hormones",
      "k": "Stimulus-response pathway; chemical vs electrical coordination; feedback regulation",
      "c": 3
     , "lab": "labs/science/neuron-reflex-lab.html"},
     {
      "n": "7. How do Organisms Reproduce?",
      "t": "Asexual reproduction — fission, budding, fragmentation, regeneration, vegetative propagation, spore formation; sexual reproduction in plants and humans; reproductive heal",
      "k": "Variation from sexual reproduction; fertilisation; contraception and reproductive health",
      "c": 2
     , "lab": "labs/science/reproduction-lab.html"},
     {
      "n": "8. Heredity",
      "t": "Mendel's experiments; monohybrid and dihybrid crosses; rules of inheritance; sex determination in humans",
      "k": "Dominant and recessive traits; segregation and independent assortment; genotype vs phenotype",
      "c": 2,
      "lab": "labs/biology/genetics-punnett.html"
     },
     {
      "n": "9. Light - Reflection and Refraction",
      "t": "Reflection at spherical mirrors; mirror formula and magnification; refraction; laws of refraction; refractive index; lenses; lens formula; power of a lens",
      "k": "Sign conventions; image formation by ray diagrams; refraction from change of speed in media",
      "c": 2,
      "lab": "labs/science/light-optics.html"
     },
     {
      "n": "10. The Human Eye and the Colourful World",
      "t": "Structure of the eye; accommodation; defects of vision and correction; dispersion through a prism; atmospheric refraction; scattering of light",
      "k": "Power of accommodation; myopia/hypermetropia correction; Tyndall scattering explains blue sky and red sunset",
      "c": 2,
      "lab": "labs/science/human-eye-lab.html"
     },
     {
      "n": "11. Electricity",
      "t": "Electric current and circuit; potential difference; Ohm's law; resistance and resistivity; series and parallel combinations; heating effect; electric power",
      "k": "V = IR; resistance depends on material and geometry; power dissipation P = VI = I^2R",
      "c": 2,
      "lab": "labs/science/electric-circuits.html"
     },
     {
      "n": "12. Magnetic Effects of Electric Current",
      "t": "Magnetic field and field lines; field due to a current-carrying conductor and solenoid; force on a current-carrying conductor; Fleming's left-hand rule; electric motor; e",
      "k": "Current produces a magnetic field; motor and generator as inverse devices; induced EMF",
      "c": 2,
      "lab": "labs/science/magnetism-current.html"
     },
     {
      "n": "13. Our Environment",
      "t": "Ecosystem components; food chains and webs; trophic levels and 10% law; ozone layer depletion; waste management and biodegradability",
      "k": "Energy flow is unidirectional and lossy; biomagnification; human impact on ecosystems",
      "c": 2,
      "lab": "labs/science/predator-prey.html"
     }
    ]
   }
  ]
 },
 {
  "cls": 11,
  "theme": "Specialization - choosing your stream",
  "subjects": [
   {
    "name": "Physics",
    "chapters": [
     {
      "n": "1. Units and Measurements",
      "t": "SI units; fundamental and derived units; measurement of length, mass, time; errors in measurement; significant figures; dimensional analysis",
      "k": "Dimensional homogeneity; error propagation; precision vs accuracy",
      "c": 3
     },
     {
      "n": "2. Motion in a Straight Line",
      "t": "Position, path length, displacement; average and instantaneous velocity and acceleration; kinematic equations; relative velocity",
      "k": "Differentiation/integration view of kinematics; graphical interpretation of slope and area",
      "c": 3
     },
     {
      "n": "3. Motion in a Plane",
      "t": "Scalars and vectors; vector addition; resolution of vectors; projectile motion; uniform circular motion",
      "k": "Independence of perpendicular components; centripetal acceleration; vector algebra",
      "c": 3,
      "lab": "labs/physics/projectile-motion.html"
     },
     {
      "n": "4. Laws of Motion",
      "t": "Newton's laws; inertia; momentum and impulse; conservation of momentum; friction; circular motion dynamics; banking of roads",
      "k": "Force as rate of change of momentum; free-body diagrams; pseudo-forces intuition",
      "c": 3
     },
     {
      "n": "5. Work, Energy and Power",
      "t": "Work by constant and variable force; work-energy theorem; kinetic and potential energy; conservation of mechanical energy; power; collisions",
      "k": "Conservative vs non-conservative forces; elastic and inelastic collisions; energy conservation",
      "c": 3
     },
     {
      "n": "6. System of Particles and Rotational Motion",
      "t": "Centre of mass; torque; angular momentum; moment of inertia; theorems of parallel and perpendicular axes; rolling motion",
      "k": "Rotational analogues of translational quantities; conservation of angular momentum",
      "c": 3
     },
     {
      "n": "7. Gravitation",
      "t": "Universal law of gravitation; acceleration due to gravity; gravitational potential energy; escape velocity; satellites and orbital motion; Kepler's laws",
      "k": "Inverse-square law; bound vs unbound orbits; geostationary satellites",
      "c": 3,
      "lab": "labs/physics/projectile-motion.html"
     },
     {
      "n": "8. Mechanical Properties of Solids",
      "t": "Stress and strain; Hooke's law; elastic moduli — Young's, bulk, shear; elastic potential energy",
      "k": "Elastic limit; stress-strain curve; material stiffness",
      "c": 3
     },
     {
      "n": "9. Mechanical Properties of Fluids",
      "t": "Pressure in fluids; Pascal's law; buoyancy and Archimedes' principle; viscosity; Stokes' law; surface tension; Bernoulli's principle; streamline flow",
      "k": "Pressure-depth relation; continuity equation; energy conservation in fluid flow",
      "c": 3
     },
     {
      "n": "10. Thermal Properties of Matter",
      "t": "Temperature and heat; thermal expansion; specific heat capacity; calorimetry; change of state and latent heat; heat transfer; Newton's law of cooling",
      "k": "Heat as energy in transit; latent heat at constant temperature; conduction/convection/radiation",
      "c": 3
     },
     {
      "n": "11. Thermodynamics",
      "t": "Thermal equilibrium and zeroth law; first law; thermodynamic processes; second law; heat engines; refrigerators; Carnot engine",
      "k": "Internal energy as a state function; entropy direction of processes; efficiency limits",
      "c": 3
     },
     {
      "n": "12. Kinetic Theory",
      "t": "Molecular nature of matter; ideal gas equation; kinetic interpretation of temperature; law of equipartition; mean free path; degrees of freedom",
      "k": "Macroscopic properties from microscopic motion; temperature as average KE per molecule",
      "c": 3,
      "lab": "labs/chemistry/ideal-gas-lab.html"
     },
     {
      "n": "13. Oscillations",
      "t": "Periodic motion; simple harmonic motion; SHM equations; energy in SHM; simple pendulum; spring oscillations; damped and forced oscillations; resonance",
      "k": "SHM as projection of uniform circular motion; restoring force proportional to displacement",
      "c": 3,
      "lab": "labs/physics/simple-pendulum.html"
     },
     {
      "n": "14. Waves",
      "t": "Transverse and longitudinal waves; wave equation; speed of a wave; superposition; reflection of waves; standing waves; beats; harmonics in strings and air columns",
      "k": "Superposition principle; nodes and antinodes; resonance in pipes and strings",
      "c": 3,
      "lab": "labs/physics/wave-motion.html"
     }
    ]
   },
   {
    "name": "Chemistry",
    "chapters": [
     {
      "n": "1. Some Basic Concepts of Chemistry",
      "t": "Laws of chemical combination; atomic and molecular mass; mole concept; molar mass; percentage composition; empirical and molecular formula; stoichiometry; concentration t",
      "k": "Mole as a bridge between mass and number; limiting reagent; dimensional analysis in chemistry",
      "c": 3
     },
     {
      "n": "2. Structure of Atom",
      "t": "Sub-atomic particles; Thomson, Rutherford and Bohr models; hydrogen spectrum; dual nature; de Broglie and Heisenberg; quantum numbers; orbitals; Aufbau, Pauli, Hund",
      "k": "Quantum mechanical model; probability distribution of electrons; electronic configuration rules",
      "c": 3,
      "lab": "labs/science/atom-builder-3d.html",
      "x": "3D"
     },
     {
      "n": "3. Classification of Elements and Periodicity in Properties",
      "t": "Development of the periodic table; modern periodic law; s, p, d, f blocks; periodic trends — atomic radius, ionisation enthalpy, electron gain enthalpy, electronegativity",
      "k": "Periodicity arises from electronic configuration; trends across periods and down groups",
      "c": 3
     , "lab": "labs/chemistry/periodic-table-lab.html"},
     {
      "n": "4. Chemical Bonding and Molecular Structure",
      "t": "Ionic and covalent bonds; Lewis structures; VSEPR theory; valence bond theory; hybridisation; molecular orbital theory; hydrogen bonding; bond parameters",
      "k": "Octet rule and its limits; geometry from electron pair repulsion; bond order and stability",
      "c": 3,
      "lab": "labs/chemistry/molecule-viewer-3d.html",
      "x": "3D"
     },
     {
      "n": "5. Thermodynamics",
      "t": "System and surroundings; internal energy; work and heat; first law; enthalpy; heat capacity; Hess's law; enthalpies of reaction; entropy; Gibbs energy; spontaneity",
      "k": "State vs path functions; spontaneity criterion (delta G < 0); thermochemical cycles",
      "c": 3
     },
     {
      "n": "6. Equilibrium",
      "t": "Physical and chemical equilibrium; law of mass action; Kc and Kp; Le Chatelier's principle; ionic equilibrium; acids and bases; pH; buffer solutions; solubility product",
      "k": "Dynamic equilibrium; shifting equilibrium under stress; degree of ionisation and common ion effect",
      "c": 3,
      "lab": "labs/chemistry/titration-lab.html"
     },
     {
      "n": "7. Redox Reactions",
      "t": "Oxidation and reduction; oxidation number; types of redox reactions; balancing redox equations; redox titrations; electrode processes",
      "k": "Electron transfer as the unifying idea; oxidising and reducing agents; ion-electron method",
      "c": 3
     },
     {
      "n": "8. Organic Chemistry - Some Basic Principles and Techniques",
      "t": "Tetravalency of carbon; IUPAC nomenclature; isomerism; fission of bonds; electrophiles and nucleophiles; inductive, resonance and hyperconjugation effects; purification a",
      "k": "Reaction mechanisms; electronic effects govern reactivity; structural representation",
      "c": 3
     },
     {
      "n": "9. Hydrocarbons",
      "t": "Alkanes, alkenes, alkynes and aromatic hydrocarbons; preparation, properties and reactions; conformations; mechanism of electrophilic substitution; directive influence; c",
      "k": "Saturation vs unsaturation; Markovnikov's rule; aromaticity and Huckel's rule",
      "c": 3,
      "lab": "labs/chemistry/molecule-viewer-3d.html",
      "x": "3D"
     }
    ]
   },
   {
    "name": "Mathematics",
    "chapters": [
     {
      "n": "1. Sets",
      "t": "Sets and representations; types of sets; subsets; Venn diagrams; union, intersection, difference, complement; practical problems",
      "k": "Set as a well-defined collection; De Morgan's laws; cardinality of unions",
      "c": 3
     , "lab": "labs/math/venn-sets-lab.html"},
     {
      "n": "2. Relations and Functions",
      "t": "Cartesian product; relations; domain, codomain, range; functions; real-valued functions and their graphs; algebra of functions",
      "k": "Function as a special relation; mapping; graphs of standard functions",
      "c": 3
     },
     {
      "n": "3. Trigonometric Functions",
      "t": "Angles and radian measure; trigonometric functions and identities; sum and difference formulas; multiple angles; general solutions of trigonometric equations",
      "k": "Unit circle definition; periodicity; identity-based transformation",
      "c": 3,
      "lab": "labs/math/unit-circle-lab.html"
     },
     {
      "n": "4. Complex Numbers and Quadratic Equations",
      "t": "Complex numbers; algebra of complex numbers; modulus and conjugate; Argand plane and polar form; quadratic equations with complex roots",
      "k": "i as root of -1; geometric representation; complex plane operations",
      "c": 3
     },
     {
      "n": "5. Linear Inequalities",
      "t": "Algebraic solution of linear inequalities in one variable; graphical solution in two variables; systems of linear inequalities",
      "k": "Solution set as a region; boundary inclusion; feasible region",
      "c": 3
     },
     {
      "n": "6. Permutations and Combinations",
      "t": "Fundamental principle of counting; factorial; permutations; combinations; simple applications",
      "k": "Ordered vs unordered selection; counting without listing; nCr and nPr relationships",
      "c": 3
     },
     {
      "n": "7. Binomial Theorem",
      "t": "Binomial theorem for positive integral indices; general and middle terms; simple applications",
      "k": "Pascal's triangle; general term formula; combinatorial coefficients",
      "c": 3
     },
     {
      "n": "8. Sequences and Series",
      "t": "Sequences; arithmetic and geometric progressions; arithmetic and geometric means; sum to n terms; infinite GP",
      "k": "General term and sum formulas; relationship between AM and GM; convergence intuition",
      "c": 3
     , "lab": "labs/math/progressions-lab.html"},
     {
      "n": "9. Straight Lines",
      "t": "Slope; angle between lines; various forms of the equation of a line; distance of a point from a line; general equation",
      "k": "Slope as rate of change; forms of a line and their conversion; perpendicularity and parallelism conditions",
      "c": 3
     },
     {
      "n": "10. Conic Sections",
      "t": "Sections of a cone; circle, parabola, ellipse, hyperbola; standard equations and properties",
      "k": "Conics from a common geometric definition; focus-directrix property; eccentricity",
      "c": 3,
      "lab": "labs/math/conic-sections-3d.html",
      "x": "3D"
     },
     {
      "n": "11. Introduction to Three Dimensional Geometry",
      "t": "Coordinate axes and planes in 3D; coordinates of a point; distance between two points; section formula",
      "k": "Extension of coordinate geometry to space; octants; 3D distance",
      "c": 3
     },
     {
      "n": "12. Limits and Derivatives",
      "t": "Intuitive idea of limit; algebra of limits; limits of trigonometric functions; derivative as a limit; derivatives of polynomial and trigonometric functions",
      "k": "Limit as approaching behaviour; derivative as instantaneous rate of change and slope of tangent",
      "c": 3
     , "lab": "labs/math/limits-lab.html"},
     {
      "n": "13. Statistics",
      "t": "Measures of dispersion — range, mean deviation, variance and standard deviation for grouped and ungrouped data; analysis of frequency distributions",
      "k": "Dispersion complements central tendency; coefficient of variation for comparison",
      "c": 3,
      "lab": "labs/math/statistics-lab.html"
     },
     {
      "n": "14. Probability",
      "t": "Random experiments; sample space; events; axiomatic approach to probability; probability of an event; addition rule; mutually exclusive events",
      "k": "Axiomatic foundation; event algebra; complement and addition theorem",
      "c": 3,
      "lab": "labs/math/probability-lab.html"
     }
    ]
   },
   {
    "name": "Biology",
    "chapters": [
     {
      "n": "1. The Living World",
      "t": "What is living; diversity in the living world; taxonomic categories; taxonomical aids — herbarium, museum, botanical gardens, keys",
      "k": "Defining characteristics of life; hierarchical taxonomy; binomial nomenclature",
      "c": 3
     },
     {
      "n": "2. Biological Classification",
      "t": "Five kingdom classification; Monera, Protista, Fungi, Plantae, Animalia; viruses, viroids, lichens",
      "k": "Criteria for kingdom-level classification; acellular entities; symbiotic associations",
      "c": 3
     },
     {
      "n": "3. Plant Kingdom",
      "t": "Algae, bryophytes, pteridophytes, gymnosperms, angiosperms; life cycles and alternation of generations",
      "k": "Progressive complexity in land adaptation; haplontic/diplontic life cycles",
      "c": 3
     },
     {
      "n": "4. Animal Kingdom",
      "t": "Basis of classification; symmetry, coelom, segmentation; phyla from Porifera to Chordata; classes of vertebrates",
      "k": "Body plan features as classification criteria; evolutionary trends in animal organisation",
      "c": 3
     },
     {
      "n": "5. Morphology of Flowering Plants",
      "t": "Root, stem, leaf, inflorescence, flower, fruit and seed; modifications; floral formula and diagram; families (Fabaceae, Solanaceae, Liliaceae)",
      "k": "Structure-function in plant organs; descriptive morphology as classification basis",
      "c": 3
     },
     {
      "n": "6. Anatomy of Flowering Plants",
      "t": "Tissue systems; meristematic and permanent tissues; anatomy of dicot and monocot root, stem and leaf; secondary growth",
      "k": "Internal organisation reflects function; vascular bundle arrangement distinguishes monocots and dicots",
      "c": 3
     },
     {
      "n": "7. Structural Organisation in Animals",
      "t": "Animal tissues — epithelial, connective, muscular, neural; morphology and anatomy of the frog (organ systems)",
      "k": "Levels of organisation; tissue to organ to organ system",
      "c": 3
     },
     {
      "n": "8. Cell: The Unit of Life",
      "t": "Cell theory; prokaryotic and eukaryotic cells; cell membrane and wall; cell organelles; nucleus; cytoskeleton; ribosomes",
      "k": "Fluid mosaic model; compartmentalisation of function; endomembrane system",
      "c": 3,
      "lab": "labs/science/plant-animal-cell.html"
     },
     {
      "n": "9. Biomolecules",
      "t": "Carbohydrates, proteins, lipids, nucleic acids; structure of proteins; enzymes; enzyme action and factors; metabolic pathways",
      "k": "Macromolecule structure determines function; enzyme specificity and active site; activation energy",
      "c": 3
     },
     {
      "n": "10. Cell Cycle and Cell Division",
      "t": "Cell cycle phases; mitosis; meiosis I and II; significance of mitosis and meiosis",
      "k": "Genetic constancy via mitosis; genetic variation and halving via meiosis; crossing over",
      "c": 3
     },
     {
      "n": "11. Photosynthesis in Higher Plants",
      "t": "Site of photosynthesis; pigments; light reaction; electron transport; C3 and C4 pathways; photorespiration; factors affecting photosynthesis",
      "k": "Light energy to chemical energy conversion; Calvin cycle; law of limiting factors",
      "c": 3,
      "lab": "labs/biology/photosynthesis-lab.html"
     },
     {
      "n": "12. Respiration in Plants",
      "t": "Glycolysis; fermentation; TCA cycle; electron transport system; oxidative phosphorylation; respiratory quotient; amphibolic pathway",
      "k": "ATP yield accounting; aerobic vs anaerobic; respiration as controlled oxidation",
      "c": 3
     },
     {
      "n": "13. Plant Growth and Development",
      "t": "Growth phases and rates; differentiation and dedifferentiation; plant growth regulators — auxin, gibberellin, cytokinin, ethylene, ABA; photoperiodism; vernalisation",
      "k": "Hormonal control of development; apical dominance; seed dormancy",
      "c": 3
     },
     {
      "n": "14. Breathing and Exchange of Gases",
      "t": "Respiratory organs; human respiratory system; mechanism of breathing; exchange and transport of gases; regulation of respiration; disorders",
      "k": "Partial pressure gradients drive gas exchange; oxygen dissociation curve; Bohr effect",
      "c": 3
     },
     {
      "n": "15. Body Fluids and Circulation",
      "t": "Blood composition; blood groups; coagulation; lymph; human circulatory system; cardiac cycle; ECG; double circulation; disorders",
      "k": "Closed double circulation; cardiac conduction; blood as a transport medium",
      "c": 3
     , "lab": "labs/biology/heart-circulation-lab.html"},
     {
      "n": "16. Excretory Products and their Elimination",
      "t": "Modes of excretion; human excretory system; urine formation; regulation of kidney function; osmoregulation; disorders and dialysis",
      "k": "Filtration-reabsorption-secretion; counter-current mechanism; homeostasis",
      "c": 3
     },
     {
      "n": "17. Locomotion and Movement",
      "t": "Types of movement; muscle structure; mechanism of muscle contraction; skeletal system; joints; disorders",
      "k": "Sliding filament theory; lever systems of bones; antagonistic muscle pairs",
      "c": 3
     },
     {
      "n": "18. Neural Control and Coordination",
      "t": "Neuron structure; generation and conduction of nerve impulse; synapse; central and peripheral nervous system; human brain; reflex action",
      "k": "Action potential and ionic basis; synaptic transmission; integration of information",
      "c": 3
     , "lab": "labs/science/neuron-reflex-lab.html"},
     {
      "n": "19. Chemical Coordination and Integration",
      "t": "Endocrine glands and hormones; hypothalamus, pituitary, thyroid, parathyroid, adrenal, pancreas, gonads; mechanism of hormone action; disorders",
      "k": "Feedback regulation; hormone-receptor specificity; endocrine vs nervous coordination",
      "c": 3
     }
    ]
   }
  ]
 },
 {
  "cls": 12,
  "theme": "Mastery - engineering, medicine & beyond",
  "subjects": [
   {
    "name": "Physics",
    "chapters": [
     {
      "n": "1. Electric Charges and Fields",
      "t": "Electric charge; Coulomb's law; superposition; electric field and field lines; electric dipole; electric flux; Gauss's law and applications",
      "k": "Field concept; superposition principle; symmetry-based field derivation via Gauss's law",
      "c": 3
     , "lab": "labs/physics/electrostatics-lab.html"},
     {
      "n": "2. Electrostatic Potential and Capacitance",
      "t": "Electric potential and potential energy; equipotential surfaces; conductors and dielectrics; polarisation; capacitors; combinations; energy stored",
      "k": "Potential as work per unit charge; capacitance depends on geometry and medium",
      "c": 3
     , "lab": "labs/physics/electrostatics-lab.html"},
     {
      "n": "3. Current Electricity",
      "t": "Electric current; drift velocity; Ohm's law; resistivity and its temperature dependence; EMF and internal resistance; Kirchhoff's rules; Wheatstone bridge; potentiometer",
      "k": "Microscopic origin of resistance; circuit analysis via conservation laws; null methods",
      "c": 3
     },
     {
      "n": "4. Moving Charges and Magnetism",
      "t": "Magnetic force on a charge and a current; Biot-Savart law; Ampere's circuital law; solenoid and toroid; cyclotron; moving coil galvanometer; force between parallel curren",
      "k": "Lorentz force; magnetic field from currents; conversion of galvanometer to ammeter/voltmeter",
      "c": 3
     },
     {
      "n": "5. Magnetism and Matter",
      "t": "Bar magnet as an equivalent solenoid; magnetic field lines; magnetisation and magnetic intensity; dia-, para- and ferromagnetism; Earth's magnetism",
      "k": "Magnetic dipole; material response to magnetic fields; hysteresis",
      "c": 3
     },
     {
      "n": "6. Electromagnetic Induction",
      "t": "Magnetic flux; Faraday's law; Lenz's law; motional EMF; eddy currents; self and mutual inductance; AC generator",
      "k": "Changing flux induces EMF; Lenz's law as energy conservation; inductance",
      "c": 3,
      "lab": "labs/physics/faraday-lab.html"
     },
     {
      "n": "7. Alternating Current",
      "t": "AC voltage and current; RMS values; AC through R, L, C and LCR circuits; phasors; resonance; power in AC; transformers",
      "k": "Reactance and impedance; phase relationships; resonance and Q-factor",
      "c": 3
     },
     {
      "n": "8. Electromagnetic Waves",
      "t": "Displacement current; nature of EM waves; transverse character; EM spectrum and uses of each region",
      "k": "Maxwell's synthesis; light as an EM wave; c = 1/sqrt(mu0*epsilon0)",
      "c": 3
     },
     {
      "n": "9. Ray Optics and Optical Instruments",
      "t": "Reflection and refraction; total internal reflection; refraction at spherical surfaces; lenses; lens maker's formula; prism; optical instruments — microscope and telescop",
      "k": "Sign conventions; magnifying power; dispersion and deviation",
      "c": 3
     },
     {
      "n": "10. Wave Optics",
      "t": "Huygens' principle; interference; Young's double slit experiment; diffraction at a single slit; polarisation; Brewster's law",
      "k": "Wave nature of light; coherence and path difference; resolving power",
      "c": 3
     },
     {
      "n": "11. Dual Nature of Radiation and Matter",
      "t": "Photoelectric effect; Einstein's photoelectric equation; work function; particle nature of light; de Broglie hypothesis; Davisson-Germer experiment",
      "k": "Wave-particle duality; threshold frequency; matter waves",
      "c": 3
     , "lab": "labs/physics/photoelectric-lab.html"},
     {
      "n": "12. Atoms",
      "t": "Rutherford's alpha-scattering experiment; Bohr model; energy levels; hydrogen spectrum series; limitations",
      "k": "Quantised energy levels; spectral lines from transitions; Bohr's postulates",
      "c": 3
     , "lab": "labs/physics/radioactivity-lab.html"},
     {
      "n": "13. Nuclei",
      "t": "Composition and size of the nucleus; mass-energy relation; mass defect; binding energy per nucleon; nuclear fission and fusion; radioactivity",
      "k": "Binding energy curve explains fission and fusion; E = mc^2; decay laws",
      "c": 3
     , "lab": "labs/physics/radioactivity-lab.html"},
     {
      "n": "14. Semiconductor Electronics",
      "t": "Energy bands in conductors, semiconductors and insulators; intrinsic and extrinsic semiconductors; p-n junction; diode characteristics; rectifiers; special purpose diodes",
      "k": "Doping and charge carriers; junction barrier and biasing; rectification",
      "c": 3
     }
    ]
   },
   {
    "name": "Chemistry",
    "chapters": [
     {
      "n": "1. Solutions",
      "t": "Types of solutions; concentration expressions; solubility; Raoult's law; ideal and non-ideal solutions; colligative properties; abnormal molar mass and van't Hoff factor",
      "k": "Colligative properties depend on number of particles; deviations from ideality; osmosis",
      "c": 3,
      "lab": "labs/chemistry/titration-lab.html"
     },
     {
      "n": "2. Electrochemistry",
      "t": "Redox reactions and electrode potential; galvanic cells; Nernst equation; conductance and molar conductivity; Kohlrausch law; electrolysis; batteries; fuel cells; corrosi",
      "k": "EMF and spontaneity link (delta G = -nFE); concentration dependence of cell potential",
      "c": 3
     },
     {
      "n": "3. Chemical Kinetics",
      "t": "Rate of reaction; factors affecting rate; order and molecularity; integrated rate equations for zero and first order; half-life; Arrhenius equation; collision theory",
      "k": "Rate law is experimental; activation energy; temperature dependence of rate",
      "c": 3,
      "lab": "labs/chemistry/kinetics-lab.html"
     },
     {
      "n": "4. The d- and f-Block Elements",
      "t": "General properties of transition elements; oxidation states; colour; magnetic properties; catalytic behaviour; complexes; lanthanoids and actinoids; potassium dichromate ",
      "k": "Variable oxidation states from d-orbital involvement; lanthanoid contraction",
      "c": 3
     },
     {
      "n": "5. Coordination Compounds",
      "t": "Werner's theory; ligands; nomenclature; isomerism; valence bond theory; crystal field theory; bonding in metal carbonyls; importance and applications",
      "k": "Coordination number and geometry; CFSE and colour; chelation",
      "c": 3
     },
     {
      "n": "6. Haloalkanes and Haloarenes",
      "t": "Nomenclature; preparation and properties; nucleophilic substitution (SN1, SN2); elimination; optical isomerism; polyhalogen compounds and their effects",
      "k": "Mechanism determines stereochemical outcome; leaving group ability; carbocation stability",
      "c": 3
     },
     {
      "n": "7. Alcohols, Phenols and Ethers",
      "t": "Classification and nomenclature; preparation, physical and chemical properties; acidity of phenols; electrophilic substitution; Williamson synthesis; important compounds",
      "k": "Hydrogen bonding effects; acidity trends via resonance; functional group interconversion",
      "c": 3
     },
     {
      "n": "8. Aldehydes, Ketones and Carboxylic Acids",
      "t": "Nomenclature; preparation; nucleophilic addition; aldol and Cannizzaro reactions; oxidation and reduction; acidity of carboxylic acids; important reactions",
      "k": "Carbonyl polarity drives nucleophilic addition; alpha-hydrogen reactivity; acidity and substituent effects",
      "c": 3
     },
     {
      "n": "9. Amines",
      "t": "Classification and nomenclature; preparation; physical and chemical properties; basicity of amines; diazonium salts and their reactions",
      "k": "Basicity trends in aqueous and gas phase; diazotisation and coupling",
      "c": 3
     },
     {
      "n": "10. Biomolecules",
      "t": "Carbohydrates — monosaccharides, disaccharides, polysaccharides; proteins — amino acids, structure levels, denaturation; enzymes; vitamins; nucleic acids DNA and RNA",
      "k": "Structure-function of biomolecules; glycosidic and peptide bonds; base pairing",
      "c": 3
     }
    ]
   },
   {
    "name": "Mathematics",
    "chapters": [
     {
      "n": "1. Relations and Functions",
      "t": "Types of relations — reflexive, symmetric, transitive, equivalence; types of functions — one-one, onto, bijective; composition and invertible functions",
      "k": "Equivalence classes; invertibility requires bijection; composition of mappings",
      "c": 3
     },
     {
      "n": "2. Inverse Trigonometric Functions",
      "t": "Definition, range, domain and principal value branches; graphs; elementary properties",
      "k": "Restricting the domain to make trigonometric functions invertible; principal values",
      "c": 3
     },
     {
      "n": "3. Matrices",
      "t": "Types of matrices; operations; transpose; symmetric and skew-symmetric; elementary operations; invertible matrices",
      "k": "Matrix as a linear transformation; non-commutative multiplication; inverse existence",
      "c": 3
     , "lab": "labs/math/matrix-lab.html"},
     {
      "n": "4. Determinants",
      "t": "Determinant of a square matrix; properties; minors and cofactors; adjoint and inverse; area of a triangle; solution of a system of linear equations",
      "k": "Determinant as a scaling factor; consistency of linear systems; Cramer-type solution",
      "c": 3
     , "lab": "labs/math/matrix-lab.html"},
     {
      "n": "5. Continuity and Differentiability",
      "t": "Continuity; differentiability; chain rule; derivatives of implicit, inverse trigonometric, exponential and logarithmic functions; logarithmic differentiation; second orde",
      "k": "Continuity as a precondition for differentiability; rules of differentiation; mean value theorems",
      "c": 3
     , "lab": "labs/math/limits-lab.html"},
     {
      "n": "6. Application of Derivatives",
      "t": "Rate of change; increasing and decreasing functions; tangents and normals; maxima and minima; first and second derivative tests",
      "k": "Derivative as rate and slope; optimisation by critical points; concavity",
      "c": 3
     , "lab": "labs/math/limits-lab.html"},
     {
      "n": "7. Integrals",
      "t": "Integration as inverse of differentiation; methods — substitution, partial fractions, by parts; definite integrals; fundamental theorem of calculus; properties",
      "k": "Antiderivative; area under a curve; the fundamental theorem linking the two",
      "c": 3
     },
     {
      "n": "8. Application of Integrals",
      "t": "Area under simple curves; area between two curves; areas of regions bounded by lines and standard curves",
      "k": "Definite integral as accumulated area; setting limits from intersections",
      "c": 3
     },
     {
      "n": "9. Differential Equations",
      "t": "Order and degree; general and particular solutions; variables separable; homogeneous; linear differential equations; formation of differential equations",
      "k": "Differential equation as a model of rate; integrating factor; family of solutions",
      "c": 3
     },
     {
      "n": "10. Vector Algebra",
      "t": "Vectors and scalars; direction cosines and ratios; addition; scalar (dot) and vector (cross) product; projection",
      "k": "Vector as magnitude with direction; dot product for angle, cross product for area/perpendicular",
      "c": 3
     },
     {
      "n": "11. Three Dimensional Geometry",
      "t": "Direction cosines and ratios of a line; equation of a line in space; angle between two lines; shortest distance between lines",
      "k": "Parametric and vector forms; skew lines; geometry via vector algebra",
      "c": 3
     },
     {
      "n": "12. Linear Programming",
      "t": "LPP terminology; mathematical formulation; graphical method; feasible and infeasible regions; optimal solution",
      "k": "Optimum lies at a vertex of the feasible region; constraint modelling",
      "c": 3
     },
     {
      "n": "13. Probability",
      "t": "Conditional probability; multiplication theorem; independent events; Bayes' theorem; random variables and probability distributions; mean of a random variable",
      "k": "Conditioning updates probability; Bayes' inversion; expected value",
      "c": 3,
      "lab": "labs/math/probability-lab.html"
     }
    ]
   },
   {
    "name": "Biology",
    "chapters": [
     {
      "n": "1. Sexual Reproduction in Flowering Plants",
      "t": "Flower structure; microsporogenesis and megasporogenesis; pollination and its types; outbreeding devices; double fertilisation; post-fertilisation events; apomixis and po",
      "k": "Double fertilisation is unique to angiosperms; pollination strategies; seed and fruit development",
      "c": 3
     },
     {
      "n": "2. Human Reproduction",
      "t": "Male and female reproductive systems; gametogenesis; menstrual cycle; fertilisation and implantation; pregnancy and embryonic development; parturition and lactation",
      "k": "Hormonal control of the reproductive cycle; gamete formation; placental function",
      "c": 3
     },
     {
      "n": "3. Reproductive Health",
      "t": "Reproductive health problems and strategies; population control and birth control methods; MTP; STIs; infertility and assisted reproductive technologies",
      "k": "Public health approach to reproduction; contraceptive mechanisms; ART (IVF, ZIFT, GIFT)",
      "c": 3
     },
     {
      "n": "4. Principles of Inheritance and Variation",
      "t": "Mendel's laws; incomplete dominance; co-dominance; multiple alleles; pleiotropy; polygenic inheritance; chromosomal theory; linkage and recombination; sex determination; ",
      "k": "Deviations from Mendelian ratios; linkage reduces independent assortment; pedigree analysis",
      "c": 3,
      "lab": "labs/biology/genetics-punnett.html"
     },
     {
      "n": "5. Molecular Basis of Inheritance",
      "t": "DNA as genetic material; DNA structure and packaging; replication; transcription; genetic code; translation; regulation of gene expression (lac operon); Human Genome Proj",
      "k": "Central dogma; semi-conservative replication; degeneracy of the genetic code",
      "c": 3,
      "lab": "labs/biology/dna-helix-3d.html",
      "x": "3D"
     },
     {
      "n": "6. Evolution",
      "t": "Origin of life; evidences of evolution; Darwinian theory; natural selection; Hardy-Weinberg principle; adaptive radiation; human evolution",
      "k": "Variation and selection as the engine of evolution; gene pool and allele frequencies",
      "c": 3,
      "lab": "labs/science/predator-prey.html"
     },
     {
      "n": "7. Human Health and Disease",
      "t": "Common infectious diseases; immunity — innate and acquired; vaccination; allergies; autoimmunity; AIDS; cancer; drug and alcohol abuse",
      "k": "Host-pathogen interaction; antigen-antibody specificity; lifestyle and health",
      "c": 3
     },
     {
      "n": "8. Microbes in Human Welfare",
      "t": "Microbes in household products; industrial products; sewage treatment; biogas production; biocontrol agents; biofertilisers",
      "k": "Applied microbiology; fermentation products; microbial ecology in waste treatment",
      "c": 3
     },
     {
      "n": "9. Biotechnology: Principles and Processes",
      "t": "Genetic engineering tools — restriction enzymes, vectors, host organisms; recombinant DNA technology steps; PCR; gel electrophoresis; bioreactors; downstream processing",
      "k": "Cutting, joining and cloning DNA; selectable markers; amplification",
      "c": 3
     , "lab": "labs/biology/biotech-pcr-lab.html"},
     {
      "n": "10. Biotechnology and its Applications",
      "t": "Biotechnological applications in agriculture — Bt crops, pest resistant plants; in medicine — insulin, gene therapy, molecular diagnosis; transgenic animals; ethical issu",
      "k": "Transgenic organisms; RNA interference; bioethics and biosafety",
      "c": 3
     , "lab": "labs/biology/biotech-pcr-lab.html"},
     {
      "n": "11. Organisms and Populations",
      "t": "Organism and its environment; major abiotic factors; responses to abiotic factors; adaptations; population attributes; population growth models; population interactions",
      "k": "Tolerance and adaptation; exponential vs logistic growth; interspecific interactions",
      "c": 3
     },
     {
      "n": "12. Ecosystem",
      "t": "Ecosystem structure and function; productivity; decomposition; energy flow; ecological pyramids; nutrient cycling; ecological succession",
      "k": "Trophic structure and 10% law; pyramid of energy is always upright; biogeochemical cycles",
      "c": 3,
      "lab": "labs/science/predator-prey.html"
     },
     {
      "n": "13. Biodiversity and Conservation",
      "t": "Levels of biodiversity; patterns of biodiversity; importance; loss of biodiversity and causes; conservation — in situ and ex situ; hotspots; sacred groves",
      "k": "Species-area relationship; The Evil Quartet; conservation strategies",
      "c": 3
     }
    ]
   }
  ]
 }
];

var COMPLEXITY = {
  1: { label: "Foundation", color: "#059669", hint: "Observe, play, name - intuition first." },
  2: { label: "Core", color: "#b45309", hint: "Board-exam central - laws, formulas, practice." },
  3: { label: "Advanced", color: "#dc2626", hint: "Analytical depth - derivations, abstraction." }
};
var RESOURCE_PACK = ["Concept notes","Worked examples","Practice quiz","Board-pattern questions"];
